"""
Ricky Smith, Lab5A:  Modules and Packages, 13 Sep 2018
"""


from Calculator_Functions import Lab5A_Calc_Interface

if __name__ == '__main__':
    Lab5A_Calc_Interface.userInterface()