"""
Ricky Smith, Lab5A:  Modules and Packages, 13 Sep 2018
"""


from Lab5C_Classes import Hero_Input_Menu

if __name__ == '__main__':
    Hero_Input_Menu.userInterface()